var mars = require('./mars');

mars.initialize();
